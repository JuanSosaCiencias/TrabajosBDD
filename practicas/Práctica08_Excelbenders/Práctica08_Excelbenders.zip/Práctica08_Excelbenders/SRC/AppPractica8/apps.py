from django.apps import AppConfig


class Apppractica8Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'AppPractica8'
